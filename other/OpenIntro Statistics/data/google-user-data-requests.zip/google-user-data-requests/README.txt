google-user-data-requests.csv

This file contains the number of requests Google receives for user information
by country.  The file also provides the percentage of requests where some data
is produced and how many user/accounts were specified in the requests.

See https://transparencyreport.google.com/user-data/overview for more
information.
