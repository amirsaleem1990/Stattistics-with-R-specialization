
The vast majority of the data sets in this repository are real, but a few are simulated. If you are only interested in real data sets, double check the documentation (see the two files in this folder) for data sets that you are interested in.
